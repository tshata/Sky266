<?php
// datastore=auditlogs;
// created_on=1604999599;
// updated_on=1604999599;
exit(0);
?>
response:{"status":1,"action":"get_logs","request_time":1604999976,"verbose":0,"output":["2020-11-10 04:19:18 ict@tech-corp.co.ls : INFO: Authentication key added and plugin enabled"],"total_entries":1,"output_data":[{"event":"notice","date":"2020-11-10","time":"09:19:18","datetime":"2020-11-10 09:19:18","timestamp":1604999958,"account":"ict@tech-corp.co.ls","username":"system","remote_addr":"127.0.0.1","message":"INFO: Authentication key added and plugin enabled","file_list":false,"file_list_count":0}]}
response:{"status":1,"action":"get_logs","request_time":1605000817,"verbose":0,"output":["2020-11-10 04:19:18 ict@tech-corp.co.ls : INFO: Authentication key added and plugin enabled"],"total_entries":1,"output_data":[{"event":"notice","date":"2020-11-10","time":"11:19:18","datetime":"2020-11-10 11:19:18","timestamp":1604999958,"account":"ict@tech-corp.co.ls","username":"system","remote_addr":"127.0.0.1","message":"INFO: Authentication key added and plugin enabled","file_list":false,"file_list_count":0}]}
