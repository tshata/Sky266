<?php
// datastore=auditqueue;
// created_on=1604999587;
// updated_on=1613380485;
exit(0);
?>
1613209475_6052:"Notice: Matete, 129.232.17.183; Wpcargo_shipment status has been changed; details: ID: 3133,Old status: publish,New status: archive,Title: SKY-031772-CARGO"
1613211772_006:"Notice: Matete, 129.232.17.183; Wpcargo_shipment status has been changed; details: ID: 2270,Old status: publish,New status: archive,Title: SKY-013495-CARGO"
1613214378_7957:"Error: 129.232.17.183; User authentication failed: Unknown"
1613278156_7292:"Error: 202.191.122.62; User authentication failed: admin"
1613293822_3762:"Warning: 68.66.248.36; Post deleted: (multiple entries): Post id: 2492,Post author: 1,Post type: revision,Post status: inherit,Post inserted: 2021-01-14 15:38:17,Post modified: 2021-01-14 15:38:17,Post guid: https:\/\/www.sky266.co.ls\/2491-revision-v1\/,Post title: SKY-021420-CARGO"
1613293822_5207:"Warning: 68.66.248.36; Post deleted: (multiple entries): Post id: 2993,Post author: 6,Post type: wpcargo_shipment,Post status: auto-draft,Post inserted: 2021-02-06 12:48:32,Post modified: 2021-02-06 12:48:32,Post guid: https:\/\/www.sky266.co.ls\/?post_type=wpcargo_shipment&p=2993,Post title: Auto Draft"
1613367060_6111:"Error: 129.232.20.91; User authentication failed: Unknown"
1613367092_4757:"Notice: 129.232.20.91; User authentication succeeded: Matete"
1613370377_6012:"Notice: Matete, 129.232.20.91; Revision status has been changed; details: ID: 3203,Old status: new,New status: inherit,Title: SKY-085224-CARGO"
1613370663_8117:"Error: 129.232.20.91; User authentication failed: Manager"
1613370872_8156:"Notice: Manager, 129.232.20.91; Wpcargo_shipment status has been changed; details: ID: 3204,Old status: new,New status: auto-draft,Title: Auto Draft"
1613375812_6544:"Error: 129.232.20.91; User authentication failed: Unknown"
1613376186_4297:"Notice: Matete, 129.232.20.91; Revision status has been changed; details: ID: 3211,Old status: new,New status: inherit,Title: SKY-007098-CARGO"
1613378484_6811:"Notice: Matete, 129.232.20.91; Wpcargo_shipment status has been changed; details: ID: 3212,Old status: draft,New status: publish,Title: SKY-057155-CARGO"
1613379806_3337:"Notice: Matete, 129.232.20.91; Wpcargo_shipment status has been changed; details: ID: 3216,Old status: new,New status: auto-draft,Title: Auto Draft"
1613380195_7754:"Notice: Matete, 129.232.20.91; Wpcargo_shipment status has been changed; details: ID: 3216,Old status: auto-draft,New status: publish,Title: SKY-007841-CARGO"
1613380195_7895:"Notice: Matete, 129.232.20.91; Revision status has been changed; details: ID: 3217,Old status: new,New status: inherit,Title: SKY-007841-CARGO"
