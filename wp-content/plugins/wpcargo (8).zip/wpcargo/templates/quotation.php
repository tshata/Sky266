
<div id="shipment-info" class="wpcargo-row detail-section" style="padding-right: 20px;">
    <div class="wpcargo-col-md-12">
        <h2><?php echo apply_filters('wpc_shipment_details_label', esc_html__('Shipment Information', 'wpcargo' ) ); ?> <span style="font-size: 14px; font-style: italic; float: right" id="booking_reference">Booking Reference: <b></b></span> </h2>
        <hr style="border: 1px solid black;"/><br>
    </div>

    <div class="wpcargo-col-md-8">
      <div class=" wpcargo-row">
        <div class="wpcargo-col-md-6">
            <p class="wpcargo-label" style="margin-bottom: 0px;"><strong><?php esc_html_e('Your Details:', 'wpcargo'); ?></strong></p>
            <p class="wpcargo-label-info" id="label_info_receiver" style="font-size: 13px; "></p>
        </div>
        <div class="wpcargo-col-md-6">
             <p class="wpcargo-label" style="margin-bottom: 0px;"><strong><?php esc_html_e('Collection Addresses:', 'wpcargo'); ?></strong></p>
             <p class="wpcargo-label-info" id="label_info_shipper" style="font-size: 13px; "></p>
        </div>
    	<div class="wpcargo-col-md-6">
        	<p class="wpcargo-label" style="margin-bottom: 0px;"><strong><?php esc_html_e('Origin:', 'wpcargo'); ?></strong></p>
            <p class="wpcargo-label-info" id="label_info_origin" style="font-size: 13px; margin-bottom: 0px;"></p>

        	<p class="wpcargo-label" style="margin-bottom: 0px;"><strong><?php  esc_html_e('Destination:', 'wpcargo'); ?></strong></p>
            <p class="wpcargo-label-info" id="label_info_dest" style="font-size: 13px; "></p>
        </div>
        <div class="wpcargo-col-md-6">
            <p class="wpcargo-label" style="margin-bottom: 0px;"><strong><?php apply_filters( 'wpc_multiple_package_header', esc_html_e( 'Collection and Clearance', 'wpcargo' ) ); ?></strong></p>
            <i><b><p class="wpcargo-label-info" id="label_info_collection" style="font-size: 13px;  margin-bottom: 0px;"></p>
            <p class="wpcargo-label-info" id="label_info_clearance" style="font-size: 13px; "></p></b></i>
        </div>
      </div>
    </div>
    <div class="wpcargo-col-md-4">
        <!--p class="wpcargo-label" style="margin-bottom: 0px;"><strong><?php apply_filters( 'wpc_multiple_package_header', esc_html_e( 'Price Estimates', 'wpcargo' ) ); ?></strong></p-->
        <div id="price_info" style="font-size: 12px;">
        </div>
    </div>
</div>

<div id="package-table" class="print-section wpcargo-table-responsive table-responsive">
 <table class=" table " class="table wpcargo-table" id="packages_table" style="width:100%;">
		<thead>
			<thead>
             <th class="wpcargo-label">Total weight estimate (kg)</th>
             <th></th>
             <th class="wpcargo-label">Total Volume Estimate (cbm)</th>
            </thead>
		</thead>
		<tbody>
           <td style="text-align:center;"  class="wpcargo-label-info"><p id="label_info_est_weight"></p></td>
           <td></td>
           <td style="text-align:center;"  class="wpcargo-label-info"> <p id="label_info_est_cbm"></p></td>

		</tbody>
	</table>
	<p class="wpcargo-label" style="margin-bottom: 10px;"><strong><?php apply_filters( 'wpc_multiple_package_header', esc_html_e( 'Packages', 'wpcargo' ) ); ?></strong></p>


    <h5 class="wpcargo-label"><strong> Goods description</strong></h5>
    <p id="label_info_goods_desc" class="wpcargo-label-info"></p>
  <?php// do_action('wpcargo_after_package_totals', $shipment ); ?>
</div>
<div> <br>
 <p class="wpcargo-label" style="margin-bottom: 10px;"><strong><?php apply_filters( 'wpc_multiple_package_header', esc_html_e( 'Terms and Conditions', 'wpcargo' ) ); ?></strong></p>
    <i><b><p class="wpcargo-label-info" style="font-size: 13px;  margin-bottom: 0px;">Quotation Valied for 24hrs.</p>
          <p class="wpcargo-label-info" style="font-size: 13px; ">To finalize Booking, You have to Pay.</p>
    </b></i>
</div>

