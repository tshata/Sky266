
 <div id="payment_items" class="shipping-form"> <!-- form step tree -->
       <?php
               $price_estimates = sanitize_text_field( $shipment->wpcargo_price_estimates);
               $price_estimates_arr = unserialize($price_estimates);
               $shipment_id = $shipment->ID;
              
       ?>
       <div class="wpcargo-row" style="padding:10px;">
        <table class="wpcargo-col-md-6" style="font-size: 12px; line-height: 25px;">
          <tr><td colspan="4"> <h2><?php echo apply_filters('wpc_receiver_details_label',esc_html__('Cost Estimate', 'wpcargo' ) ); ?></h2> <hr/> </td></tr>
          <tr><td>Item</td><td>Unit Price</td><td>Qty</td><td>Total Price</td></tr>
          <?php
              $items = unserialize(get_settings_items()->meta_data);
              $total_price = 0;
              foreach($price_estimates_arr as $key => $value){
                if($key == "freight") echo '<tr><td>Freight <td>M'.$price_estimates_arr[$key]["price"].' </td><td>'.$price_estimates_arr[$key]["qty"].$price_estimates_arr[$key]["unit"].'</td><td id="'.$key.'">M'.$price_estimates_arr[$key]["total"].'</td></tr>';
                else echo '<tr><td>'.$items[$key]["item_name"].' <td>M'.$price_estimates_arr[$key]["price"].' </td><td>'.$price_estimates_arr[$key]["qty"].'</td><td id="'.$key.'">M'.$price_estimates_arr[$key]["total"].'</td></tr>';

               $total_price+=$price_estimates_arr[$key]["total"];
              }
           ?>
           <tr><td colspan="3" style="border-top: solid 2px;"><b>Total Estimate Cost:</b></td><td style="border-top: solid 2px; border-bottom: double 2px;" id="label_info_tt_c"><b>M <?php echo $total_price; ?></b></td></tr>
       </table>
       <div class="wpcargo-col-md-6" style="padding-left: 40px;">
        <?php $wpcargo_payment_history = unserialize(get_post_meta($shipment_id, 'wpcargo_payment_history', true ));
              $amount_paid = 0;
              if(is_array($wpcargo_payment_history)) {foreach($wpcargo_payment_history AS $key=>$values){
                       $amount_paid+=(float)str_replace(",","",$values['amount']);
                  } }
        ?>
           <div id="form" style="<?php echo (!empty($wpcargo_payment_history))? 'display:none;': ''; ?>">
              <!--h2><?php echo apply_filters('wpc_receiver_details_label',esc_html__('Pay Now', 'wpcargo' ) ); ?></h2-->
               <p><br> You have to pay a minimum amount of : <strong>M<?php echo $total_price*30/100 ?></strong>, So that your booking will be approved</p>
               <p><br><strong><?php apply_filters( 'wpc_multiple_package_header', esc_html_e( 'Select method of payment', 'wpcargo' ) ); ?></strong></p>

            <div style="margin-left: 50px;" id="payment_boxes">
              <label><input style="width: 15px; height: 15px;" type='checkbox' name="mobile"  id="mobile" onclick="payments_toggle(this)" data-group='payments'><label style="font: bolder;">Mpesa/Ecocash </label></label><br>
              <label><input style="width: 15px; height: 15px;" type='checkbox' name="cash" id="cash" onclick="payments_toggle(this)" data-group='payments'><label style="font: bolder;">Cash</label></label><br>
              <label><input style="width: 15px; height: 15px;" type='checkbox' name="bank" id="bank" onclick="payments_toggle(this)" data-group='payments'><label style="font: bolder;">Bank</label></label><br>
            </div>

            <div class="sf-content" id="payment_details" style="display: none;">
               <p class="wpcargo-label" style="margin-bottom: 10px;"><strong id="heading"><?php apply_filters( 'wpc_multiple_package_header', esc_html_e( 'Mpesa/Ecocash Payment Details', 'wpcargo' ) ); ?></strong></p>
               <div>
                  <div class="sf_columns column_3">
                      <input type="text" id="payment_identifier" placeholder="Phone Number Used" data-required="true">
                  </div>
                  <div class="sf_columns column_3">
                      <input type="text" id="payment_reference" placeholder="Reference" data-required="true" data-email="true">
                  </div>
               </div>
               <div>
                  <div class="sf_columns column_3">
                      <input type="date" id="payment_date" placeholder="Date of Payment" data-required="true" data-confirm="true">
                  </div>
                  <div class="sf_columns column_3">
                      <input type="money" id="payment_amount" placeholder="Amount Paid" data-required="true" data-confirm="true">
                  </div>
               </div>
               <br>
               <button type="button" id="submit_payment" onclick="submit_payment()">Submit</button>
            </div>
         <input type="hidden" id="post_id" value="<?php echo sanitize_text_field( $shipment->ID); ?>">
        </div>
        <p id="info" style="<?php echo (empty($wpcargo_payment_history))? 'display:none;': ''; ?>"><br><br><?php echo "You have paid M".number_format((float)$amount_paid, 2, '.', '')." of the Total amount of M".number_format((float)$total_price, 2, '.', '')." Remaining Balance is M".number_format((float)($total_price-$amount_paid), 2, '.', '');?>.<br> <a href='home'>Close</a></p>
    </div>
  </div> <br>
 </div>
<script>
   function payments_toggle(btn){
          $("#payment_details").hide();
          $("#payment_boxes input").prop("checked",false);
          $("#payment_details input").val("");
          $("#payment_details").show();
          $("#"+btn.id).prop("checked",true);
          if(btn.id == "mobile"){
              $("#payment_details .wpcargo-label #heading").text("Mpesa/Ecocash Payment Details");
              $("#payment_details #payment_identifier").attr("placeholder","Phone Number Used");
              $("#payment_details #payment_reference").attr("placeholder","Reference");
              $("#payment_details #payment_date").attr("placeholder","Date of Payment");
              $("#payment_details #payment_amount").attr("placeholder","Amount Paid");
              $('#payment_items #payment_method').val("Mobile Money")
          }
          else if(btn.id == "cash"){
              $("#payment_details .wpcargo-label #heading").text("Cash Payment Details");
              $("#payment_details #payment_identifier").attr("placeholder","Place of Payment");
              $("#payment_details #payment_reference").attr("placeholder","Receipt Number");
              $("#payment_details #payment_date").attr("placeholder","Date of Payment");
              $("#payment_details #payment_amount").attr("placeholder","Amount Paid");
              $('#payment_items #payment_method').val("Cash");
          }
          else if(btn.id == "bank"){
              $("#payment_details .wpcargo-label #heading").text("Bank Payment Details");
              $("#payment_details #payment_identifier").attr("placeholder","Bank Name");
              $("#payment_details #payment_reference").attr("placeholder","Reference");
              $("#payment_details #payment_date").attr("placeholder","Date of Payment");
              $("#payment_details #payment_amount").attr("placeholder","Amount Paid");
              $('#payment_items #payment_method').val("Bank");
          }
   }
   $(document).ready(function () {
       mutually_exclusive_checkboxes();
    });
  function submit_payment(){
       $.ajax({
              url: wpcargoAJAXHandler.ajax_url,
              type:"POST",
              data: {
                  action    : 'client_save_payment_action',
                  post_id : $('#payment_items #post_id').val(),
                  payment_date : $('#payment_items #payment_date').val(),
                  payment_method : $('#payment_items #payment_method').val(),
                  payment_identifier : $('#payment_items #payment_identifier').val(),
                  payment_reference : $('#payment_items #payment_reference').val(),
                  payment_amount : $('#payment_items #payment_amount').val(),
              },
              success:function(data) {
                  $('#info').html( data );
                  $('#form').hide();
                  $('#info').show();
              },
              error: function(errorThrown){
                  $('#info').html("Error retrieving data. Please try again.");
                  $('#form').hide();
                  $('#info').show();
              }

          });
  }
 </script>
