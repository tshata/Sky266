 <style>
#payment_details ::placeholder {/* Chrome, Firefox, Opera, Safari 10.1+ */
  color: black;
  opacity: 1; /* Firefox */
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
  color: black;
}

::-ms-input-placeholder { /* Microsoft Edge */
  color: black;
}
#payment_items {
    width: 700px;
}

</style>
 <div id="payment_items" class="shipping-form"> <!-- form step tree -->

       <div class="wpcargo-row" style="padding:10px;">
        <div class="wpcargo-col-md-d14" style="background:dimgray; padding:1em;font-size:1.2em;color:white;width:50%;">
         <h5><strong>ESTIMATE</strong></h5>
        <!--p class="wpcargo-label" style="margin-bottom: 0px;"><strong><?php apply_filters( 'wpc_multiple_package_header', esc_html_e( 'Price Estimates', 'wpcargo' ) ); ?></strong></p-->
        <div id="price" style="font-size: 12px;">
            <?php
                  echo "Price: " . sanitize_text_field( $_POST["item_price"] );
               //$price_estimates = wpcargo_get_postmeta( $_SESSION["current_id"], 'wpcargo_payment_history', true );;


               //echo $price_estimates ;
              //$myaArr = get_post_meta($_SESSION["current_id"],'wpcargo_price_estimates',true);
              // echo $myaArr . "<br>";
                /*$result = preg_split("/[:,;]/",$myaArr,-1);
               print_r($result);    */
               //$array = get_post_meta($_SESSION["current_id"],'wpcargo_price_estimates',true);
               //print_r($array) ;
              // $results = unserialize(json_encode($array));
             // var_dump($results);   ?>


        <div id="price_tables" class="wpcargo-row">
      </div>
        </div>
    </div>
       <div class="wpcargo-col-md-6" style="padding-left: 4px;">
        <div style="margin-left:.3em;" id="payment_boxes">
               <p>To Activate this Booking, Please  pay a minimum amount of <span ><strong>M <?php ?></strong></span></p><br>
              <input style="width: 15px; height: 15px;" type='checkbox' name="mobileMpesa"  id="mobileMpesa" onclick="payments_toggle(this)" data-group='payments'><span >Mpesa</span><br>
              <input style="width: 15px; height: 15px;" type='checkbox' name="mobileEco"  id="mobileEco" onclick="payments_toggle(this)" data-group='payments'><span >Ecocash </span><br>
              <!-- <label><input style="width: 15px; height: 15px;" type='checkbox' name="cash" id="cash" onclick="payments_toggle(this)" data-group='payments'><label >Cash</label></label><br>  -->
              <input style="width: 15px; height: 15px;" type='checkbox' name="bank" id="bank" onclick="payments_toggle(this)" data-group='payments'><span >Bank EFT/Deposit</span><br><br><br>
             <!-- <label><input style="width: 15px; height: 15px;" type='checkbox' name="bank" id="bank" onclick="payments_toggle(this)" data-group='payments'><label >Card</label></label><br>-->
            </div>
             <p></p>

         <input type="hidden" id="post_id" value="<?php echo sanitize_text_field( $_SESSION["current_id"]); ?>">
             <br>
            <br><br>
            <button style="float:right;" type="button" id="nextBtn" >Pay</button>
            <button style="float:right;margin-right:.4em;" type="button" id="close" >Close</button>
        </div>
        <br>
   <p id="info" style="<?php echo (empty($wpcargo_payment_history))? 'display:none;': ''; ?>"><?php echo "You have paid M".number_format((float)$amount_paid, 2, '.', '')." of the Total amount of M".number_format((float)$total_price, 2, '.', '')." Remaining Balance is M".number_format((float)($total_price-$amount_paid), 2, '.', '');?>.</p>
   <?php wpcargo_include_template( 'pay_methods', $shipment );
         //do_action('wpcargo_after_package_details', $shipment );
   ?>
    </div>
  </div>

<script>
   function payments_toggle(btn){
        var selected_trip = ($("#trip_1").prop('checked')==true) ? $('#trip_1_div').html() : $('#trip_2_div').html();
        $("#price").html(selected_trip);
          $("#payment_details").hide();
          $("#payment_boxes input").prop("checked",false);
          $("#payment_details input").val("");
          $("#payment_details").show();
          $("#"+btn.id).prop("checked",true);
          $("#nextBtn").css("background","#187CC9");
          $("#nextBtn").attr("disabled", false);
          if(btn.id == "mobileMpesa"){
              $("#payment_details .wpcargo-label #heading").text("Mpesa Payment Details");
              $("#payment_details #company_details").text("PAY TO: 57555325");
              $("#payment_details #payment_identifier").attr("placeholder","Phone Number Used");
              $("#payment_details #payment_reference").attr("placeholder","Reference");
              $("#payment_details #payment_date").attr("placeholder","Date of Payment");
              $("#payment_details #payment_amount").attr("placeholder","Amount Paid");
              $('#payment_items #payment_method').val("Mobile Money")
          }
          else if(btn.id == "mobileEco"){
              $("#payment_details .wpcargo-label #heading").text("Ecocash Payment Details");
              $("#payment_details #company_details").text("PAY TO: 62555325");
              $("#payment_details #payment_identifier").attr("placeholder","Phone Number Used");
              $("#payment_details #payment_reference").attr("placeholder","Reference");
              $("#payment_details #payment_date").attr("placeholder","Date of Payment");
              $("#payment_details #payment_amount").attr("placeholder","Amount Paid");
              $('#payment_items #payment_method').val("Mobile Money")
          }
         /* else if(btn.id == "cash"){
              $("#payment_details .wpcargo-label #heading").text("Cash Payment Details");
              $("#payment_details #payment_identifier").attr("placeholder","Place of Payment");
              $("#payment_details #payment_reference").attr("placeholder","Receipt Number");
              $("#payment_details #payment_date").attr("placeholder","Date of Payment");
              $("#payment_details #payment_amount").attr("placeholder","Amount Paid");
              $('#payment_items #payment_method').val("Cash");
          } */
          else if(btn.id == "bank"){
              $("#payment_details .wpcargo-label #heading").text("Bank Payment Details");
              $("#payment_details #company_details").text("PAY TO: 9080007532411 (STANDARD LESOTHO BANK)");
              $("#payment_details #payment_identifier").attr("placeholder","Bank Name");
              $("#payment_details #payment_reference").attr("placeholder","Reference");
              $("#payment_details #payment_date").attr("placeholder","Date of Payment");
              $("#payment_details #payment_amount").attr("placeholder","Amount Paid");
              $('#payment_items #payment_method').val("Bank");
          }
   }
   $(document).ready(function () {
       mutually_exclusive_checkboxes();
    });
    document.getElementById("close").onclick = function(){
            window.location("/");
        };

 </script>
