if(
	typeof cpcff_redirect != 'undefined' &&
	typeof cpcff_redirect['url'] != 'undefined'
)
{
	document.location.href = cpcff_redirect['url'];
}