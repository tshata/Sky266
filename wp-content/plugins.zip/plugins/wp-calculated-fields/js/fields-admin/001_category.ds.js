if( typeof $.fbuilder[ 'categoryList' ] == 'undefined' ) $.fbuilder[ 'categoryList' ] = [];
$.fbuilder.categoryList[20]={
		title : "Form Controls with Datasource Connection",
		description : "<div style='color: #666;border: 1px solid #EF7E59;display: block;padding: 5px;background: #FBF0EC;border-radius: 4px;text-align: center;'><em>Available only in the <a href='http://cff.dwbooster.com/download' target='_blank'>Developer and Platinum versions</a> of the plugin</em></div>"
	};
