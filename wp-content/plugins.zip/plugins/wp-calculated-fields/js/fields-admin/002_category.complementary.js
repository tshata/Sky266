if( typeof $.fbuilder[ 'categoryList' ] == 'undefined' ) $.fbuilder[ 'categoryList' ] = [];
$.fbuilder.categoryList[30]={
		title : "Complementary Blocks",
		description : "<div class='complementary-blocks-category' style='color: #666;border: 1px solid #EF7E59;display: block;padding: 5px;background: #FBF0EC;border-radius: 4px;text-align: center;'><em>Need more controls or operations?<br />Install the <a href='https://wordpress.org/plugins/cp-blocks/' target='_blank' style='font-weight:bold;'>CP BLOCKS</a> plugin:<br />- with buttons<br />- testimonial blocks<br />- additional features<br />...and more</em></div>"
	};
